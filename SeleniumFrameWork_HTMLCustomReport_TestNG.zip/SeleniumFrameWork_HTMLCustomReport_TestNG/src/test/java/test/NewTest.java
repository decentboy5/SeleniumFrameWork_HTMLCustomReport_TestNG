package test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import accelerators.ActionEngine;
import junit.framework.Assert;

public class NewTest extends ActionEngine {

	@Test(priority=1)
	public void FirstScenario() throws Throwable {

		launch();
		System.out.println("Hello");
		type(By.name("q"), "One", "Search Box");
		Thread.sleep(5000);
	}

	@Test(priority=2)
	public void ABCD() throws Throwable {
		launch();
		System.out.println("Hello");
		type(By.name("q1"), "Two", "Search Box");

	}
}
